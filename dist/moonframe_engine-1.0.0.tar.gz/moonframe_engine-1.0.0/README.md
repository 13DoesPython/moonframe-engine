# MoonFrame

MoonFrame is a Python game development framework built on top of Pyglet. It provides a simple and intuitive API for creating 2D games, handling graphics, input, and more. Its kinda like a mix between Pygame and SDL2, but with a more modern and Python design. This README will give you a quick overview of how to get started with MoonFrame and what features it offers.

## Installation
You can install MoonFrame using pip:

```bash
pip install moonframe
```

## Basic Usage
Here's a simple example of how to create a window and render a texture with controls using MoonFrame:

```python
import moonframe as mfr

class GameApp:
    def __init__(self, renderer, input_handler):
        self.renderer = renderer
        self.input = input_handler
        self.x, self.y = 100, 100
        
        # Load a texture
        self.cat = mfr.Texture(renderer, "cat.avif", x=self.x, y=self.y)
        self.cat.resize(128, 128)

    def update(self):
        if self.input.is_key_pressed('right'): self.x += 5
        if self.input.is_key_pressed('down'): self.y += 5
        if self.input.is_key_pressed('up'): self.y -= 5
        if self.input.is_key_pressed('left'): self.x -= 5

        self.cat.set_pos(self.x, self.y)

    def draw(self):
        self.renderer.set_draw_color(20, 20, 30)
        self.renderer.clear()

win = mfr.Window(800, 600, "MoonFrame Test")
renderer = mfr.Renderer(win)
event = mfr.Event()
input_handler = mfr.Input(win)
app = GameApp(renderer, input_handler)

running = True
while running:
    while win.poll_event(win, event):
        if event.type == event.QUIT:
            running = False
            break

    if not running:
        break
    
    app.update()
    app.draw()
    renderer.present()

win.handle.close()
```

## Features
- **Window Management**: Create and manage game windows with ease.
- **Rendering**: Draw textures, shapes, and more with a simple API.
- **Input Handling**: Capture keyboard and mouse input for interactive games.
- **Event System**: Handle events like window resizing, quitting, and custom events.
- **Collision Detection**: Built-in support for detecting collisions between game objects.

## Methods and Classes
- `Window`: Create and manage game windows.
- `Renderer`: Handle all rendering operations.
- `Texture`: Load and manipulate textures.
- `Input`: Capture and process user input.
- `Drawable`: Base class for drawable objects.
- `Event`: Handle various events in the game loop.
- `Collision`: Utility class for collision detection and response.

### Methods
- `Window.poll_event()`: Poll for events from the window.
- `Renderer.set_draw_color()`: Set the color for drawing operations.
- `Renderer.clear()`: Clear the rendering target.
- `Texture.resize()`: Resize a texture to specified dimensions.
- `Texture.set_pos()`: Set the position of a texture.
- `Input.is_key_pressed()`: Check if a specific key is currently pressed.
- `Collision.is_colliding()`: Check for collisions between two objects.
- And many more!

## Contributing
Contributions to MoonFrame are welcome! If you have an idea for a new feature or want to fix a bug, please open an issue or submit a pull request on GitHub.

## License
MoonFrame is licensed under the MIT License. See the LICENSE file for more details.

## Version History
- **1.0.0** - Initial release with basic window management, rendering, and input handling.